# Java-Rummy
An implementation of the classic card game Rummy in Java using Swing/AWT. It can be played against computer or human players online or off.
